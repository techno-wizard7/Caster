#include <ArduinoTrace.h>

#include "Menu.h"


// Option constructors
Menu::Option::Option(VoidFunc func, const char* name) 
    : type(VOID_FUNC), voidFunc(new VoidFunc(func)), name(name) {}

Menu::Option::Option(IntCharFunc func, const char* name) 
    : type(INT_CHAR_FUNC), intCharFunc(new IntCharFunc(func)), name(name) {}

Menu::Option::Option(Menu* subMenu, const char* name) 
    : type(SUB_MENU), subMenu(subMenu), name(name) {}

// Copy constructor
Menu::Option::Option(const Option& other) 
    : type(other.type), name(other.name) {
    switch (type) {
        case VOID_FUNC:
            voidFunc = new VoidFunc(*other.voidFunc);
            break;
        case INT_CHAR_FUNC:
            intCharFunc = new IntCharFunc(*other.intCharFunc);
            break;
        case SUB_MENU:
            subMenu = other.subMenu;
            break;
    }
}

// Copy assignment operator
Menu::Option& Menu::Option::operator=(const Option& other) {
    if (this != &other) {
        if (type == VOID_FUNC) delete voidFunc;
        if (type == INT_CHAR_FUNC) delete intCharFunc;

        type = other.type;
        name = other.name;
        switch (type) {
            case VOID_FUNC:
                voidFunc = new VoidFunc(*other.voidFunc);
                break;
            case INT_CHAR_FUNC:
                intCharFunc = new IntCharFunc(*other.intCharFunc);
                break;
            case SUB_MENU:
                subMenu = other.subMenu;
                break;
        }
    }
    return *this;
}

// Destructor
Menu::Option::~Option() {
    if (type == VOID_FUNC) delete voidFunc;
    if (type == INT_CHAR_FUNC) delete intCharFunc;
    if (type == SUB_MENU) delete subMenu;
}

// Constructor
Menu::Menu(const char* name) 
    : name(name), parentMenu(nullptr), currentMenu(this) {}
// Add a void function to the menu
void Menu::addOption(VoidFunc func, const char* name) {
    options.emplace_back(func, name);
}

Menu::~Menu() {}

// Add an int, char** function to the menu
void Menu::addOption(IntCharFunc func, const char* name) {
    options.emplace_back(func, name);
}

// Add a submenu
void Menu::addSubMenu(Menu* subMenu, const char* name) {
    subMenu->parentMenu = this;
    options.emplace_back(subMenu, name);
}

// Reorder options
void Menu::moveOption(size_t from, size_t to) {
    if (from < options.size() && to < options.size()) {
        Option temp = options[from];
        options.erase(options.begin() + from);
        options.insert(options.begin() + to, temp);
    }
}

// Remove an option
void Menu::removeOption(size_t index) {
    if (index < options.size()) {
        options.erase(options.begin() + index);
    }
}

// Get menu options as a vector of strings
void Menu::getMenuOptions(std::vector<const char*>& menuOptions) {
    menuOptions.clear();
    menuOptions.push_back(name);
    for (const auto& option : currentMenu->options) {
        menuOptions.push_back(option.name);
    }
    if (currentMenu->parentMenu) {
        menuOptions.push_back("Back");
    }
}
//Get menu option name
const char* Menu::getOption(int i){
  return currentMenu->options[i].name;
}

const int Menu::getSize(){
  return currentMenu->options.size();
}

// Run the menu
int Menu::run(int choice) {
    if (choice <= 0){
      setRootMenu();
      return 0;
    } else if (choice > 0 && choice <= currentMenu->options.size()) {
        choice--;
        switch (currentMenu->options[choice].type) {
            case VOID_FUNC:
                return (*currentMenu->options[choice].voidFunc)();
            case INT_CHAR_FUNC:
                return (*currentMenu->options[choice].intCharFunc)(0, nullptr);
            case SUB_MENU:
                setCurrentMenu(currentMenu->options[choice].subMenu);
                return 0;  //currentMenu->run(1); // Start the submenu
        }
    } else if (currentMenu->parentMenu && choice >= currentMenu->options.size()) {
        goBack();
        return 0;
    } else {
        return -1; // Invalid choice
    }
    return -1; // Default return for safety
}
// Run a specific program in the menu
int Menu::runProgram(int index, int argc, char** argv) {
    return executeOption(index, argc, argv);
}

// Execute a specific option
int Menu::executeOption(int index, int argc, char** argv) {
    if (index >= 0 && index < currentMenu->options.size()) {
        switch (currentMenu->options[index].type) {
            case VOID_FUNC:
                return (*currentMenu->options[index].voidFunc)();
            case INT_CHAR_FUNC:
                return (*currentMenu->options[index].intCharFunc)(argc, argv);
            case SUB_MENU:
                return currentMenu->options[index].subMenu->run(0);
        }
    } else {
        return -1; // Invalid program index
    }
    return -1; // Default return for safety
}

// Navigate back to the parent menu
int Menu::goBack() {
    if (currentMenu->parentMenu) {
        setCurrentMenu(currentMenu->parentMenu);
    }
    return 0;
}

// Set the menu back to the root menu
int Menu::setRootMenu() {
    setCurrentMenu(this);
  return 0;
}

// Set the current menu context
void Menu::setCurrentMenu(Menu* menu) {
  currentMenu = menu;
}
