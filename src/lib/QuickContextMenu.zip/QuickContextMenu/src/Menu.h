#ifndef MENU_H
#define MENU_H

#ifndef __AVR__
#include <Vector.h>
#else
#include <vector>
#endif
#include <functional>

class Menu {
public:
    using VoidFunc = std::function<int()>;
    using IntCharFunc = std::function<int(int, char**)>;
    enum OptionType { VOID_FUNC, INT_CHAR_FUNC, SUB_MENU };

    struct Option {
        OptionType type;
        union {
            VoidFunc* voidFunc;
            IntCharFunc* intCharFunc;
            Menu* subMenu;
        };
        const char* name;

        Option(VoidFunc func, const char* name);
        Option(IntCharFunc func, const char* name);
        Option(Menu* subMenu, const char* name);
        Option(const Option& other);
        Option& operator=(const Option& other);
        ~Option();
    };

    Menu(const char* name);
    ~Menu();

    void addOption(VoidFunc func, const char* name);
    void addOption(IntCharFunc func, const char* name);
    void addSubMenu(Menu* subMenu, const char* name);

    void moveOption(size_t from, size_t to);
    void removeOption(size_t index);

    int run(int choice);
    int runProgram(int index, int argc = 0, char** argv = nullptr);

    int goBack();
    int setRootMenu();

    void getMenuOptions(std::vector<const char*>& options);
    const char* getOption(int i);
    const int getSize();

private:
    const char* name;
    std::vector<Option> options;
    Menu* parentMenu;
    Menu* currentMenu; // To keep track of the current menu context

    int executeOption(int index, int argc = 0, char** argv = nullptr);
    void setCurrentMenu(Menu* menu);
};

#endif // MENU_H
