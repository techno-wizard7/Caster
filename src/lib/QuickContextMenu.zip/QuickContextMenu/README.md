# QuickContextMenu

an arduino library for quickly building abstract menus, that can dynamically assign functions and submenu's, toggle between options, display details, build from external memory and return to the root menu, quickly.

designed to be used for the [Caster](https://github.com/techno-wizard7/Caster) project; adapted to be made into an independant library.
